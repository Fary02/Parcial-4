# Se crean arrays a ocupar;

alumnos = []; 

nombre = []; 

edad = []; 

asignaturas = []; 

asignatura = []; 

nota = []; 

estado = []; 

# Creacion de function a ocupar;

def menu_Pricipal():
  
  print("\n*****Menu Principal*****"); 
  print("1. Agregar estudiante"); 
  print("2. Buscar estudiante"); 
  print("3. Eliminar estudiante"); 
  print("4. Actualizar estados"); 
  print("5. Mostrar estudiantes"); 
  print("6. Salir"); 
  
def agregar_Estudiante():
  
  # Solicitud de datos de cada estudiante; 
  
  nombre_Estudiante = str(input("\nPor favor, digite el nombre del estudiante: ")); 
  
  if nombre_Estudiante.isspace() == False and nombre_Estudiante.isalpha() == True:
    
    edad_Estudiante = int(input("\nPor favor, digite la edad del estudiante: ")); 
    
    if edad_Estudiante > 0 and edad_Estudiante < 100:
      
      asignatura_Estudiante = str(input("\nPor favor digite la asignatura: ")); 
      
      if asignatura_Estudiante.isspace() == False and asignatura_Estudiante.isalpha() == True:
        
        nota_Estudiante = float(input("\nPor favor, ingrese la nota del estudiante: ")); 
        
        if nota_Estudiante >= 1.0 and nota_Estudiante <= 7.0:
          
          estado_Estudiante = False; 
          
          estado.append(estado_Estudiante); 
          
          nota.append(nota_Estudiante); 
          
          asignatura.append(asignatura_Estudiante); 
          
          edad.append(edad_Estudiante); 
          
          nombre.append(nombre_Estudiante); 
          
        else:
    
          print("\n¡ERROR!, ingrese una nota valida (numero decimal entre 1.0 a 7.0)"); 
          
      else:
    
        print("\n¡ERROR!, ingrese una asignatura valida (solo texto)"); 
      
    else:
      
      print("\n¡ERROR!, la edad debe ser un numero entero mayor a 0 y menor a 100"); 
    
  else:
    
    print("\n¡ERROR!, ingrese un valor valido (solo texto)"); 
  
# Function muestra estudiante;
  
def mostrar_Estudiantes():
  
   return alumnos.append(print(f"\nAlumno: {nombre}, Edad: {edad}, Asignatura: {asignatura}, Nota: {nota}, Estado: {estado}")); 

# Inicio de menu; 

while True:
  
  
  menu_Pricipal(); 
  
  # Intenta; 
  
  try:
    
    # Solicitud de opcion; 
    
    opcion = int(input("\nPor favor, digite una opcion: ")); 
    
    if opcion == 1:
     
      agregar_Estudiante(); 
      
    elif opcion == 5:
      
      mostrar_Estudiantes(); 
      
    elif opcion == 6:
      
      print("\nGracias por usar el sistema. Vuelva Pronto") 
      
      break; 
      
    elif opcion != 1 or opcion != 5 or opcion != 6:
      
      print("\n¡ERROR!, ingrese una opcion valida (1, 5 o 6)"); 
    
    
  # Manejo de errores en try;
    
  except ValueError:
    
    print("\n¡ERROR!, ingrese un valor valido"); 