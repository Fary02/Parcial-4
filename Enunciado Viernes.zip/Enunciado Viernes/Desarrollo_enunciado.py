# Mensaje bienvenida;

print("\n*****¡Hola, bienvenido/a!*****"); 

# Inicializacion de array;

numeros = []; 

# Inicio de programa;

while True:
  
  # Intenta;
  
  try: 
    
    # Menu;
  
    print("\n*****Menu*****"); 
    print("1. Comenzar"); 
    print("2. Mostrar resultados"); 
    print("3. Finalizar programa"); 
    
    # Solicitud de opcion;
  
    opcion = int(input("\nPor, favor digite una opcion: ")); 
    
    # Si opcion 1;
    
    if opcion == 1:
      
      # For in para los numeros;
      
      for i in range(5):
        
        # Aviso de cantidad de numeros restantes a digitar;
        
        print(f"\n¡Registro {i + 1} de 5!"); 
        
        # Solicitud de numero;
        
        numero = int(input("\nPor, favor Digite SOLO numeros enteros: ")); 
        
        # Al final coloca el numero al final del array; 
        
        numeros.append(numero); 
       

 
 
  # except Exception para manejo de errores;

  except Exception:
  
    print("\n¡ERROR!, digite una opcion valida"); 