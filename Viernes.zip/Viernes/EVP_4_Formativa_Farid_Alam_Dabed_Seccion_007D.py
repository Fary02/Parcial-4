
pacientes = []; 

rut = []; 

nombre = []; 

edad = []; 

temperatura = []; 

atentido = False; 

def menu_Principal():
  
  print("\n*****Menu Principal*****"); 
  print("1. Agregar paciente"); 
  print("2. Buscar paciente"); 
  print("3. Eliminar paciente"); 
  print("4. Actualizar estado"); 
  print("5. Mostrar pacientes"); 
  print("6. Salir"); 
  
def agregar_Paciente():
  
  nombre = str(input("\nPor favor, digite su nombre: ")); 
  
  rut = str(input("\nPor favor, digite su rut SIN DIGITO verificador: ")); 
  
  rutLen = len(rut)
  
  if rutLen != 8:
    
    return print("\n¡ERROR!, debe ingresar un valor valido"); 
   
  else:
    
    return print(f"\nPaciente: {nombre} ¡Registrado Exitosamente!"); 




while True:
  
  try:
    
    menu_Principal(); 
    
    opcion = int(input("\nPor favor, digite una opcion: ")); 
    
    if opcion == 1:
      
       
     agregar_Paciente(); 
    
    
    
    
  except ValueError:
    
    print("\n¡ERROR!, digite un valor valido"); 